# Church Prompteur Pro — prototype Flutter Android

Cette base comprend un prompteur, un compte à rebours, un lecteur vidéo avec option de boucle, une interface personnalisable et des maquettes de bibliothèque/projection.

## Important : état du projet

Ce ZIP est un **projet source**, pas un APK déjà compilé. Le code n'a pas été compilé ni testé sur un Samsung Galaxy A34 dans cet environnement. La bibliothèque persistante complète et le contrôle à distance téléphone-PC via Wi-Fi ne sont pas encore implémentés; l'écran compagnon est une maquette.

## Générer l'APK sans ordinateur, avec GitHub Actions

Le dossier `.github/workflows/build-apk.yml` contient un workflow de compilation cloud. Il compile le projet dans les serveurs GitHub et publie l'APK comme artefact téléchargeable.

1. Dans le navigateur du téléphone, connectez-vous ou créez un compte sur GitHub.
2. Créez un nouveau dépôt (repository), par exemple `church-prompteur-pro`.
3. Décompressez ce ZIP sur le téléphone, puis téléversez les fichiers **du dossier du projet** dans le dépôt en conservant les dossiers `lib`, `web_projection` et `.github/workflows` ainsi que `pubspec.yaml`.
4. Ouvrez l'onglet **Actions**, sélectionnez **Build Church Prompteur Pro APK**, puis appuyez sur **Run workflow** si le workflow ne démarre pas automatiquement.
5. Attendez que l'exécution soit terminée avec succès (coche verte). Ouvrez l'exécution et téléchargez l'artefact `Church-Prompteur-Pro-APK`.
6. Décompressez l'artefact téléchargé : il contient `app-release.apk`. Ouvrez ce fichier sur le Samsung Galaxy A34 et autorisez l'installation depuis cette source si Android le demande.

Les libellés exacts peuvent varier selon la langue et la version de GitHub. Si la compilation échoue, ouvrez l'exécution et partagez le journal d'erreur pour que le code puisse être corrigé.

## Compiler localement (si un ordinateur devient disponible)

```bash
flutter pub get
flutter create --platforms=android --org org.churchprompteur .
flutter build apk --release
```

APK attendu : `build/app/outputs/flutter-apk/app-release.apk`.
