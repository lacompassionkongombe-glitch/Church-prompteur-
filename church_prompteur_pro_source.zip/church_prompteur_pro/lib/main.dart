import 'dart:async';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

void main() => runApp(const ChurchPrompteurApp());

class ChurchPrompteurApp extends StatefulWidget {
  const ChurchPrompteurApp({super.key});
  @override
  State<ChurchPrompteurApp> createState() => _ChurchPrompteurAppState();
}

class _ChurchPrompteurAppState extends State<ChurchPrompteurApp> {
  Color seed = const Color(0xFFB58A3A);
  bool dark = true;
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Church Prompteur Pro',
    themeMode: dark ? ThemeMode.dark : ThemeMode.light,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: seed), useMaterial3: true),
    darkTheme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.dark), useMaterial3: true),
    home: HomeScreen(onTheme: (c, d) => setState(() { seed = c; dark = d; })),
  );
}

class HomeScreen extends StatefulWidget {
  final void Function(Color, bool) onTheme;
  const HomeScreen({super.key, required this.onTheme});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  int index = 0;
  final pages = const [Dashboard(), PrompterPage(), TimerPage(), VideoPage(), LibraryPage()];
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Church Prompteur Pro'), actions: [
      IconButton(tooltip: 'Paramètres', icon: const Icon(Icons.settings_outlined), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SettingsPage(onTheme: widget.onTheme)))),
    ]),
    body: IndexedStack(index: index, children: pages),
    bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (v) => setState(() => index = v), destinations: const [
      NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Accueil'),
      NavigationDestination(icon: Icon(Icons.subject), label: 'Prompteur'),
      NavigationDestination(icon: Icon(Icons.timer_outlined), label: 'Chrono'),
      NavigationDestination(icon: Icon(Icons.movie_outlined), label: 'Vidéos'),
      NavigationDestination(icon: Icon(Icons.library_music_outlined), label: 'Bibliothèque'),
    ]),
  );
}

class Dashboard extends StatelessWidget {
  const Dashboard({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: const LinearGradient(colors: [Color(0xFF242424), Color(0xFF55401D)])), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(Icons.church, size: 38, color: Color(0xFFE2BE73)), SizedBox(height: 18), Text('Tout le culte sous contrôle.', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold, color: Colors.white)), SizedBox(height: 8), Text('Textes • Chants • Vidéos • Chronomètre', style: TextStyle(color: Colors.white70)),
    ])), const SizedBox(height: 18),
    const Text('Accès rapide', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)), const SizedBox(height: 10),
    const FeatureTile(icon: Icons.subject, title: 'Prompteur', subtitle: 'Texte en grand et défilement', color: Colors.blue),
    const FeatureTile(icon: Icons.timer, title: 'Chronomètre de prédication', subtitle: 'Compte à rebours personnalisable', color: Colors.orange),
    const FeatureTile(icon: Icons.repeat, title: 'Vidéos en boucle', subtitle: 'Lecture répétée automatique', color: Colors.green),
    const FeatureTile(icon: Icons.cast, title: 'Projection externe', subtitle: 'Prévu via écran compatible ou récepteur PC', color: Colors.purple),
    const Padding(padding: EdgeInsets.only(top: 12), child: Text('Prototype de départ : la projection distante téléphone-PC nécessite un récepteur compagnon et une connexion au même réseau Wi-Fi.', style: TextStyle(fontSize: 12, color: Colors.grey))),
  ]);
}
class FeatureTile extends StatelessWidget {
  final IconData icon; final String title; final String subtitle; final MaterialColor color;
  const FeatureTile({super.key, required this.icon, required this.title, required this.subtitle, required this.color});
  @override
  Widget build(BuildContext context) => Card(child: ListTile(leading: CircleAvatar(backgroundColor: color.withValues(alpha: .15), child: Icon(icon, color: color)), title: Text(title), subtitle: Text(subtitle)));
}

class PrompterPage extends StatefulWidget { const PrompterPage({super.key}); @override State<PrompterPage> createState() => _PrompterPageState(); }
class _PrompterPageState extends State<PrompterPage> {
  final controller = ScrollController(); final textController = TextEditingController(text: 'Bienvenue à tous dans la présence de Dieu.\n\nPrenons un moment pour ouvrir nos cœurs et nous préparer à recevoir la Parole.\n\n« Ta parole est une lampe à mes pieds, et une lumière sur mon sentier. » — Psaume 119:105');
  double fontSize = 32; bool running = false; Timer? timer;
  void toggle() { if (running) { timer?.cancel(); setState(() => running = false); } else { setState(() => running = true); timer = Timer.periodic(const Duration(milliseconds: 40), (_) { if (controller.hasClients) { final max = controller.position.maxScrollExtent; if (controller.offset >= max) { timer?.cancel(); setState(() => running = false); } else { controller.jumpTo((controller.offset + 1).clamp(0, max).toDouble()); } } }); } }
  @override void dispose() { timer?.cancel(); controller.dispose(); textController.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Column(children: [Padding(padding: const EdgeInsets.all(12), child: TextField(controller: textController, maxLines: 3, decoration: const InputDecoration(labelText: 'Texte à afficher', border: OutlineInputBorder()), onChanged: (_) => setState(() {}))), Row(children: [const Text('Taille'), Expanded(child: Slider(min: 20, max: 60, value: fontSize, onChanged: (v) => setState(() => fontSize = v))), IconButton(onPressed: toggle, icon: Icon(running ? Icons.pause : Icons.play_arrow)), IconButton(onPressed: () { timer?.cancel(); setState(() { running = false; }); if (controller.hasClients) controller.jumpTo(0); }, icon: const Icon(Icons.restart_alt))]), Expanded(child: Container(color: Colors.black, child: SingleChildScrollView(controller: controller, padding: const EdgeInsets.all(24), child: Text(textController.text, style: TextStyle(color: Colors.white, fontSize: fontSize, height: 1.5, fontWeight: FontWeight.w600)))))]);
}

class TimerPage extends StatefulWidget { const TimerPage({super.key}); @override State<TimerPage> createState() => _TimerPageState(); }
class _TimerPageState extends State<TimerPage> {
  int total = 30 * 60; int remaining = 30 * 60; Timer? ticker; bool active = false;
  String get formatted => '${(remaining ~/ 3600).toString().padLeft(2, '0')}:${((remaining % 3600) ~/ 60).toString().padLeft(2, '0')}:${(remaining % 60).toString().padLeft(2, '0')}';
  void start() { if (active) { ticker?.cancel(); setState(() => active = false); return; } if (remaining <= 0) setState(() => remaining = total); setState(() => active = true); ticker = Timer.periodic(const Duration(seconds: 1), (t) { if (remaining <= 1) { t.cancel(); setState(() { remaining = 0; active = false; }); _finished(); } else { setState(() => remaining--); } }); }
  Future<void> _finished() async { if (!mounted) return; await showDialog<void>(context: context, builder: (_) => AlertDialog(title: const Text('Temps écoulé'), content: const Text('Le compte à rebours est terminé.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))])); }
  Future<void> setDuration() async { final h = TextEditingController(text: (total ~/ 3600).toString()); final m = TextEditingController(text: ((total % 3600) ~/ 60).toString()); final s = TextEditingController(text: (total % 60).toString()); final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: const Text('Définir la durée'), content: Row(children: [Expanded(child: TextField(controller: h, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Heures'))), const SizedBox(width: 8), Expanded(child: TextField(controller: m, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Minutes'))), const SizedBox(width: 8), Expanded(child: TextField(controller: s, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Secondes')))]), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Annuler')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Valider'))])); if (ok == true) { final seconds = (((int.tryParse(h.text) ?? 0).clamp(0, 99) * 3600) + ((int.tryParse(m.text) ?? 0).clamp(0, 59) * 60) + (int.tryParse(s.text) ?? 0).clamp(0, 59)).toInt(); ticker?.cancel(); setState(() { total = seconds; remaining = seconds; active = false; }); } }
  @override void dispose() { ticker?.cancel(); super.dispose(); }
  @override Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [const Icon(Icons.timer, size: 54), const SizedBox(height: 18), Text(formatted, style: const TextStyle(fontSize: 56, fontWeight: FontWeight.bold, fontFeatures: [])), const SizedBox(height: 18), Wrap(spacing: 12, children: [FilledButton.icon(onPressed: start, icon: Icon(active ? Icons.pause : Icons.play_arrow), label: Text(active ? 'Pause' : 'Démarrer')), OutlinedButton.icon(onPressed: setDuration, icon: const Icon(Icons.edit), label: const Text('Définir')), OutlinedButton.icon(onPressed: () { ticker?.cancel(); setState(() { remaining = total; active = false; }); }, icon: const Icon(Icons.restart_alt), label: const Text('Réinitialiser'))]), const SizedBox(height: 16), const Text('Le compte à rebours reste affiché sur cet écran. La projection externe sera reliée au module de projection compagnon.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey))])));
}

class VideoPage extends StatefulWidget { const VideoPage({super.key}); @override State<VideoPage> createState() => _VideoPageState(); }
class _VideoPageState extends State<VideoPage> {
  VideoPlayerController? player; bool loop = true; String? error;
  Future<void> pick() async { final result = await FilePicker.platform.pickFiles(type: FileType.video); if (result == null || result.files.single.path == null) return; await player?.dispose(); final p = VideoPlayerController.file(File(result.files.single.path!)); try { await p.initialize(); await p.setLooping(loop); await p.play(); setState(() { player = p; error = null; }); } catch (e) { await p.dispose(); setState(() => error = 'Impossible de lire cette vidéo : $e'); } }
  @override void dispose() { player?.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [SwitchListTile(title: const Text('Lecture en boucle'), subtitle: const Text('Redémarrer automatiquement à la fin'), value: loop, onChanged: (v) async { setState(() => loop = v); await player?.setLooping(v); }), FilledButton.icon(onPressed: pick, icon: const Icon(Icons.video_library), label: const Text('Choisir une vidéo')), const SizedBox(height: 16), if (error != null) Text(error!, style: const TextStyle(color: Colors.red)), if (player != null && player!.value.isInitialized) AspectRatio(aspectRatio: player!.value.aspectRatio, child: VideoPlayer(player!)) else const Padding(padding: EdgeInsets.all(30), child: Column(children: [Icon(Icons.ondemand_video, size: 70), SizedBox(height: 12), Text('Choisissez une vidéo depuis votre appareil.')],)), if (player != null) Row(mainAxisAlignment: MainAxisAlignment.center, children: [IconButton(onPressed: () => player!.seekTo(Duration.zero), icon: const Icon(Icons.replay)), IconButton(onPressed: () => setState(() => player!.value.isPlaying ? player!.pause() : player!.play()), icon: Icon(player!.value.isPlaying ? Icons.pause_circle : Icons.play_circle, size: 42))])]);
}

class LibraryPage extends StatelessWidget { const LibraryPage({super.key}); @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: const [Text('Bibliothèque', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), SizedBox(height: 12), Card(child: ListTile(leading: Icon(Icons.music_note), title: Text('Chants'), subtitle: Text('Gestion des paroles : à connecter à la sauvegarde locale.'))), Card(child: ListTile(leading: Icon(Icons.menu_book), title: Text('Versets bibliques'), subtitle: Text('Ajouter les textes bibliques souhaités. Une base de données biblique n’est pas incluse.'))), Card(child: ListTile(leading: Icon(Icons.folder_open), title: Text('Textes enregistrés'), subtitle: Text('La bibliothèque persistante sera ajoutée dans la prochaine étape.')))]); }

class SettingsPage extends StatefulWidget { final void Function(Color, bool) onTheme; const SettingsPage({super.key, required this.onTheme}); @override State<SettingsPage> createState() => _SettingsPageState(); }
class _SettingsPageState extends State<SettingsPage> {
  bool dark = true; Color color = const Color(0xFFB58A3A);
  final options = const [Color(0xFFB58A3A), Colors.blue, Colors.green, Colors.deepPurple, Colors.red, Colors.teal];
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Personnalisation')), body: ListView(padding: const EdgeInsets.all(16), children: [SwitchListTile(title: const Text('Mode sombre'), value: dark, onChanged: (v) { setState(() => dark = v); widget.onTheme(color, dark); }), const ListTile(title: Text('Couleur principale'), subtitle: Text('Choisissez une couleur pour l’interface')), Wrap(spacing: 12, children: options.map((c) => InkWell(onTap: () { setState(() => color = c); widget.onTheme(color, dark); }, child: CircleAvatar(backgroundColor: c, child: color == c ? const Icon(Icons.check, color: Colors.white) : null))).toList()), const SizedBox(height: 24), const Text('Projection téléphone → PC : nécessite un récepteur compagnon connecté au même réseau Wi-Fi. Cette version de départ ne comprend pas encore le contrôle distant.') ])); }
}
